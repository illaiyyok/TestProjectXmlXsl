package com.wrox.algorithms.lists;

/**
 * Concrete tests for {@link LinkedList}.
 *
 */
public class LinkedListTest extends AbstractListTestCase {
    protected List createList() {
        return new LinkedList();
    }
}
