package com.wrox.algorithms.maps;

/**
 */
public class HashMapTest extends AbstractMapTestCase {
    protected Map createMap() {
        return new HashMap();
    }
}
