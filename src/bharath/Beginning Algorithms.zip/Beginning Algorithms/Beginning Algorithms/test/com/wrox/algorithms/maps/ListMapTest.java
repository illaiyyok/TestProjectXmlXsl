package com.wrox.algorithms.maps;

/**
 */
public class ListMapTest extends AbstractMapTestCase {
    protected Map createMap() {
        return new ListMap();
    }
}
