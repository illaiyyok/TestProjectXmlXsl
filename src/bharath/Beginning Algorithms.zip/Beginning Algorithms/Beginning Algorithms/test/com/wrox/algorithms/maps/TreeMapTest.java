package com.wrox.algorithms.maps;

/**
 * Test cases for {@link TreeMap}.
 * 
 */
public class TreeMapTest extends AbstractMapTestCase {
    protected Map createMap() {
        return new TreeMap();
    }
}
