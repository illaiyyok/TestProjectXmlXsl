package com.wrox.algorithms.sets;

/**
 * Test cases for {@link HashSet}.
 *
 */
public class HashSetTest extends AbstractSetTestCase {
    protected Set createSet() {
        return new HashSet();
    }
}
