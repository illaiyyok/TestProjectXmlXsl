package com.wrox.algorithms.sets;

/**
 * Test cases for {@link ListSet}.
 *
 */
public class ListSetTest extends AbstractSetTestCase {
    protected Set createSet() {
        return new ListSet();
    }
}
