package com.wrox.algorithms.sets;

/**
 * Test cases for {@link SortedListSet}.
 * 
 */
public class SortedListSetTest extends AbstractSetTestCase {
    protected Set createSet() {
        return new SortedListSet();
    }
}
