package com.wrox.algorithms.sets;

/**
 * Test cases for {@link TreeSet}.
 *
 */
public class TreeSetTest extends AbstractSetTestCase {
    protected Set createSet() {
        return new TreeSet();
    }
}
