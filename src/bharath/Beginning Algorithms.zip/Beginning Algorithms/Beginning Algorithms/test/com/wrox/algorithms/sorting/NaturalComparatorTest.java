package com.wrox.algorithms.sorting;

import junit.framework.TestCase;

/**
 * Test cases for {@link NaturalComparator}.
 *
 */
public class NaturalComparatorTest extends TestCase {
    public void testLessThan() {
        assertTrue(NaturalComparator.INSTANCE.compare("A", "B") < 0);
    }

    public void testGreaterThan() {
        assertTrue(NaturalComparator.INSTANCE.compare("B", "A") > 0);
    }

    public void testEqualTo() {
        assertTrue(NaturalComparator.INSTANCE.compare("A", "A") == 0);
    }
}
